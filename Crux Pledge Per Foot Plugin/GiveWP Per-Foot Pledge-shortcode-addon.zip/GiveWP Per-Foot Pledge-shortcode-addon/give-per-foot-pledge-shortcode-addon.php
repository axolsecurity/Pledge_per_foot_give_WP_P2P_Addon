<?php
/**
 * Plugin Name: GiveWP Per-Foot Pledge — Shortcode Add-on
 * Description: Adds the pledge form as a shortcode: [per-foot-pledge] (alias: [gppf_pledge_form]). Submits to the base plugin’s handler.
 * Version: 1.0.0
 * Author: Axolsoft LLC
 * License: GPLv2 or later
 * Text Domain: gppf-shortcode
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define('GPPF_SHORTCODE_VERSION', '1.0.0');

add_action('init', function () {
    add_shortcode('per-foot-pledge', 'gppf_shortcode_render_form');
    add_shortcode('gppf_pledge_form', 'gppf_shortcode_render_form');
});

function gppf_shortcode_render_form( $atts = [] , $content = '' ) {
    $fundraiser_id   = isset($_GET['fundraiser_id']) ? sanitize_text_field($_GET['fundraiser_id']) : '';
    $fundraiser_name = isset($_GET['fundraiser_name']) ? sanitize_text_field($_GET['fundraiser_name']) : '';

    $fundraiser_html = '';
    if ( $fundraiser_name || $fundraiser_id ) {
        $who = $fundraiser_name ? $fundraiser_name : ( $fundraiser_id ? sprintf(__('Fundraiser #%s','gppf-shortcode'), $fundraiser_id) : '' );
        if ( $who ) {
            $fundraiser_html = '<div class="gppf-fundraiser-target">'. sprintf( esc_html__( 'Pledging in support of %s', 'gppf-shortcode' ), esc_html( $who ) ) .'</div>';
        }
    }

    ob_start();
    ?>
    <div class="gppf-embed-wrap">
      <?php echo $fundraiser_html; ?>
      <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" class="gppf-form">
        <?php wp_nonce_field('gppf_create_pledge','gppf_nonce'); ?>
        <input type="hidden" name="action" value="gppf_create_pledge" />
        <input type="hidden" name="gppf_fundraiser_id" value="<?php echo esc_attr($fundraiser_id); ?>" />
        <input type="hidden" name="gppf_fundraiser_name" value="<?php echo esc_attr($fundraiser_name); ?>" />

        <h2 class="gppf-title"><?php echo esc_html__('Pledge Per Foot','gppf-shortcode'); ?></h2>

        <div class="gppf-grid">
          <div class="gppf-field">
            <label><?php esc_html_e('First name','gppf-shortcode'); ?> <span class="gppf-req">*</span></label>
            <input type="text" name="gppf_first_name" required>
          </div>
          <div class="gppf-field">
            <label><?php esc_html_e('Last name','gppf-shortcode'); ?> <span class="gppf-req">*</span></label>
            <input type="text" name="gppf_last_name" required>
          </div>
          <div class="gppf-field">
            <label><?php esc_html_e('Email address','gppf-shortcode'); ?> <span class="gppf-req">*</span></label>
            <input type="email" name="gppf_email" required>
          </div>
          <div class="gppf-field">
            <label><?php esc_html_e('Phone','gppf-shortcode'); ?></label>
            <input type="text" name="gppf_phone">
          </div>
        </div>

        <div class="gppf-grid">
          <div class="gppf-field">
            <label><?php esc_html_e('Pledge amount ($/foot)','gppf-shortcode'); ?> <span class="gppf-req">*</span></label>
            <input type="number" name="gppf_amount_per_foot" step="0.01" min="0" required>
          </div>
          <div class="gppf-field">
            <label><?php esc_html_e('Footage cap (optional)','gppf-shortcode'); ?></label>
            <input type="number" name="gppf_footage_cap" min="0">
          </div>
        </div>

        <p class="gppf-disclaimer">
          <label>
            <input type="checkbox" name="gppf_disclaimer" required>
            <span><?php esc_html_e('At the end of the competition, you will receive an invoice for your pledge multiplied by the number of feet climbed, up to your cap.','gppf-shortcode'); ?></span>
          </label>
        </p>

        <div class="gppf-actions">
          <button type="submit" class="gppf-submit"><?php esc_html_e('Submit Pledge','gppf-shortcode'); ?></button>
        </div>
      </form>
    </div>
    <?php
    return ob_get_clean();
}

add_action('wp_enqueue_scripts', function(){
    if ( is_admin() ) return;
    if ( file_exists( plugin_dir_path(__FILE__) . 'assets/css/shortcode.css' ) ) {
        wp_register_style(
            'gppf-shortcode',
            plugins_url('assets/css/shortcode.css', __FILE__),
            array(),
            GPPF_SHORTCODE_VERSION
        );
        wp_enqueue_style('gppf-shortcode');
    }
}, 20);
