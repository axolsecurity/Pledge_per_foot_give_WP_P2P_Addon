GiveWP Per-Foot Pledge — Shortcode Add-on

