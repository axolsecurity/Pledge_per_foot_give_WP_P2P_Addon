<?php
/**
 * Plugin Name: GPPF Pledge Disclaimer Update
 * Description: Adds an italicized disclaimer beneath the pledge agreement checkbox on the Per-Foot Pledge form only (class .gppf-form). Skips Gravity Forms.
 * Version: 1.0.1
 * Author: ChatGPT
 * License: GPL-2.0-or-later
 */

if ( ! defined('ABSPATH') ) { exit; }

add_action('wp_enqueue_scripts', function () {
    // Register and enqueue a tiny script + styles on the front-end
    wp_register_script('gppf-pledge-disclaimer-update', plugin_dir_url(__FILE__) . 'gppf-pledge-disclaimer-update.js', array(), '1.0.1', true);
    wp_register_style('gppf-pledge-disclaimer-update', false);
    wp_enqueue_script('gppf-pledge-disclaimer-update');
    wp_enqueue_style('gppf-pledge-disclaimer-update');

    $css = '
    .gppf-disclaimer-note {
        font-style: italic;
        font-size: 0.95em;
        margin: 6px 0 0 0;
        color: #444;
    }';
    wp_add_inline_style('gppf-pledge-disclaimer-update', $css);

    // Pass in the final disclaimer string
    $text = 'I understand that at the end of the competition, my card will be automatically charged for my total pledge — calculated as my pledge amount per foot multiplied by the number of feet climbed by the climber I support, up to my selected cap if one was set.';
    wp_add_inline_script('gppf-pledge-disclaimer-update', 'window.GPPF_PLEDGE_DISCLAIMER_TEXT = '.wp_json_encode($text).';', 'before');
}, 20);

