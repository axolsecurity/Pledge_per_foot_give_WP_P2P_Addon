(function(){
  function insertDisclaimer() {
    var txt = (window.GPPF_PLEDGE_DISCLAIMER_TEXT || '').trim();
    if (!txt) return;

    // Only operate within Per-Foot Pledge forms: <form class="gppf-form">
    var forms = Array.prototype.slice.call(document.querySelectorAll('form.gppf-form'));
    if (!forms.length) return;

    forms.forEach(function(form){
      try {
        // Skip if this form is (or is inside) a Gravity Forms wrapper
        if (form.closest('.gform_wrapper, form[id^="gform_"], [class*="gravityform"], [id*="gravityform"]')) return;

        // Find the exact pledge agreement checkbox (by name)
        var checkbox = form.querySelector('input[type="checkbox"][name="gppf_disclaimer"]');
        if (!checkbox) return;

        // Avoid duplicate insertion
        if (checkbox.__gppf_disclaimer_inserted) return;
        checkbox.__gppf_disclaimer_inserted = true;

        // Create paragraph and insert directly under the checkbox/label block
        var p = document.createElement('p');
        p.className = 'gppf-disclaimer-note';
        p.textContent = txt;

        // Prefer to insert right after the label that references the checkbox
        var label = form.querySelector('label[for="'+checkbox.id+'"]');
        if (label && label.parentNode) {
          label.parentNode.insertBefore(p, label.nextSibling);
        } else if (checkbox.parentNode) {
          checkbox.parentNode.insertBefore(p, checkbox.nextSibling);
        } else {
          form.appendChild(p);
        }

        // Accessibility: associate with aria-describedby
        var id = 'gppf-disclaimer-' + Math.random().toString(36).slice(2,8);
        p.id = id;
        var prev = checkbox.getAttribute('aria-describedby');
        checkbox.setAttribute('aria-describedby', prev ? (prev + ' ' + id) : id);
      } catch(e){ /* no-op */ }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', insertDisclaimer);
  } else {
    insertDisclaimer();
  }
  // Also try after short delays to catch shortcode/AJAX renders.
  setTimeout(insertDisclaimer, 600);
  setTimeout(insertDisclaimer, 1500);
})();
