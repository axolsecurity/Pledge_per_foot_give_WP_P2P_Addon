<?php
/**
 * Plugin Name: GiveWP Per-Foot Pledge Lite
 * Plugin URI:  https://axolsoft.com/
 * Description: Per-foot pledges for GiveWP + P2P. Adds "Pledge Per Foot" button, pledge CPT, Stripe charge tools, and email notices.
 * Version:     1.1.3
 * Author:      Axolsoft, LLC
 * Author URI:  https://axolsoft.com/
 * License:     GPLv2 or later
 * Text Domain: gppf
 */

if (!defined('ABSPATH')) { exit; }

define('GPPF_VER', '1.1.2');
define('GPPF_SLUG', 'givewp-per-foot-pledge-lite');
define('GPPF_OPTION', 'gppf_settings');

require_once __DIR__ . '/includes/cpt.php';
require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/emails.php';
require_once __DIR__ . '/includes/charges.php';
require_once __DIR__ . '/includes/button.php';

/**
 * Activation: ensure options exist.
 */
register_activation_hook(__FILE__, function() {
    $defaults = array(
        'pledge_page_slug' => 'per-foot-pledge',
        'admin_emails'     => get_option('admin_email'),
        'stripe_pk'        => '',
        'stripe_sk'        => '',
        'email_pledge_subject_admin' => 'New pledge for {fundraiser_name} on {site_name}',
        'email_pledge_body_admin'    => "A new pledge was created.\n\nDonor: {donor_name} <{donor_email}>\nFundraiser: {fundraiser_name}\nRate: ${rate}/ft\nCap: ${cap}\nFeet (est): {feet}\nPledge ID: {pledge_id}\n",
        'email_pledge_subject_donor' => 'Thanks for your pledge to {fundraiser_name}',
        'email_pledge_body_donor'    => "Thanks, {donor_name}!\n\nYou pledged ${rate}/ft up to ${cap} for {fundraiser_name}.\nWe will email you when the event is finalized.\n\n— {site_name}",
        'email_charge_success_subject_donor' => 'Receipt: your pledge to {fundraiser_name}',
        'email_charge_success_body_donor'    => "Hi {donor_name},\n\nWe just charged your card ${amount} for {feet} ft at ${rate}/ft (cap ${cap}).\nStripe ID: {payment_intent}\n\nThank you!",
        'email_charge_success_subject_admin' => 'Pledge charged: {fundraiser_name} / {donor_name}',
        'email_charge_success_body_admin'    => "Charged ${amount} for pledge {pledge_id}\nFundraiser: {fundraiser_name}\nDonor: {donor_name} <{donor_email}>\nStripe ID: {payment_intent}",
        'email_charge_fail_subject_donor'    => 'Payment failed for your pledge to {fundraiser_name}',
        'email_charge_fail_body_donor'       => "Hi {donor_name},\n\nWe attempted to charge ${amount} for {feet} ft at ${rate}/ft (cap ${cap}) but it failed.\nError: {error}\n\nPlease contact us.",
        'email_charge_fail_subject_admin'    => 'Pledge charge failed: {fundraiser_name} / {donor_name}',
        'email_charge_fail_body_admin'       => "Failed to charge pledge {pledge_id}\nFundraiser: {fundraiser_name}\nDonor: {donor_name} <{donor_email}>\nError: {error}",
    );
    $opt = get_option(GPPF_OPTION, array());
    update_option(GPPF_OPTION, wp_parse_args($opt, $defaults));
});

