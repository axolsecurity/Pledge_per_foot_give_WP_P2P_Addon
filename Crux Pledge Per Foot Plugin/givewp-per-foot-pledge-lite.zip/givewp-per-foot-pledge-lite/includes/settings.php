<?php
if (!defined('ABSPATH')) { exit; }

function gppf_get_settings(){
    return get_option(GPPF_OPTION, array());
}
function gppf_update_settings($data){
    $opt = gppf_get_settings();
    $opt = array_merge($opt, $data);
    update_option(GPPF_OPTION, $opt);
    return $opt;
}

function gppf_admin_settings(){
    if (!current_user_can('manage_options')) return;
    $msg = '';
    if(isset($_POST['gppf_save_settings']) && check_admin_referer('gppf_save_settings')){
        $save = array(
            'pledge_page_slug' => sanitize_title($_POST['pledge_page_slug'] ?? 'per-foot-pledge'),
            'stripe_pk'        => sanitize_text_field($_POST['stripe_pk'] ?? ''),
            'stripe_sk'        => sanitize_text_field($_POST['stripe_sk'] ?? ''),
            'admin_emails'     => sanitize_text_field($_POST['admin_emails'] ?? get_option('admin_email')),
            'email_pledge_subject_admin' => wp_kses_post($_POST['email_pledge_subject_admin'] ?? ''),
            'email_pledge_body_admin'    => wp_kses_post($_POST['email_pledge_body_admin'] ?? ''),
            'email_pledge_subject_donor' => wp_kses_post($_POST['email_pledge_subject_donor'] ?? ''),
            'email_pledge_body_donor'    => wp_kses_post($_POST['email_pledge_body_donor'] ?? ''),
            'email_charge_success_subject_donor' => wp_kses_post($_POST['email_charge_success_subject_donor'] ?? ''),
            'email_charge_success_body_donor'    => wp_kses_post($_POST['email_charge_success_body_donor'] ?? ''),
            'email_charge_success_subject_admin' => wp_kses_post($_POST['email_charge_success_subject_admin'] ?? ''),
            'email_charge_success_body_admin'    => wp_kses_post($_POST['email_charge_success_body_admin'] ?? ''),
            'email_charge_fail_subject_donor'    => wp_kses_post($_POST['email_charge_fail_subject_donor'] ?? ''),
            'email_charge_fail_body_donor'       => wp_kses_post($_POST['email_charge_fail_body_donor'] ?? ''),
            'email_charge_fail_subject_admin'    => wp_kses_post($_POST['email_charge_fail_subject_admin'] ?? ''),
            'email_charge_fail_body_admin'       => wp_kses_post($_POST['email_charge_fail_body_admin'] ?? ''),
        );
        gppf_update_settings($save);
        $msg = '<div class="updated"><p>Settings saved.</p></div>';
    }
    $opt = gppf_get_settings();
    $verified = gppf_verify_stripe($opt['stripe_sk'] ?? '');
    ?>
    <div class="wrap">
        <h1>Per-Foot Pledges — Settings</h1>
        <?php echo $msg; ?>
        <form method="post">
            <?php wp_nonce_field('gppf_save_settings'); ?>
            <table class="form-table">
                <tr><th scope="row">Pledge page slug</th>
                    <td><input type="text" name="pledge_page_slug" value="<?php echo esc_attr($opt['pledge_page_slug'] ?? 'per-foot-pledge'); ?>" class="regular-text">
                        <p class="description">Public page that hosts the pledge form. Example: <code>/per-foot-pledge</code></p>
                    </td>
                </tr>
                <tr><th scope="row">Stripe Publishable key</th>
                    <td><input type="text" name="stripe_pk" value="<?php echo esc_attr($opt['stripe_pk'] ?? ''); ?>" class="regular-text"></td>
                </tr>
                <tr><th scope="row">Stripe Secret key</th>
                    <td>
                        <input type="text" name="stripe_sk" value="<?php echo esc_attr($opt['stripe_sk'] ?? ''); ?>" class="regular-text">
                        <?php if($verified['ok']): ?>
                            <span style="color:#0a0; font-weight:700; margin-left:10px;">Verified (<?php echo esc_html($verified['acct']); ?>)</span>
                        <?php else: ?>
                            <span style="color:#a00; font-weight:700; margin-left:10px;">Not connected</span>
                            <?php if(!empty($verified['err'])) echo '<div style="color:#a00">'.esc_html($verified['err']).'</div>'; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr><th scope="row">Admin emails</th>
                    <td><input type="text" name="admin_emails" value="<?php echo esc_attr($opt['admin_emails'] ?? get_option('admin_email')); ?>" class="regular-text">
                        <p class="description">Comma-separated list of admin recipients.</p>
                    </td>
                </tr>
            </table>
            <h2>Email templates</h2>
            <p>Available tags: {site_name},{fundraiser_name},{donor_name},{donor_email},{amount},{feet},{rate},{cap},{pledge_id},{payment_intent},{error}</p>
            <table class="form-table">
                <tr><th>Admin: New pledge subject/body</th><td>
                    <input type="text" name="email_pledge_subject_admin" value="<?php echo esc_attr($opt['email_pledge_subject_admin'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_pledge_body_admin" rows="6" class="large-text"><?php echo esc_textarea($opt['email_pledge_body_admin'] ?? ''); ?></textarea>
                </td></tr>
                <tr><th>Donor: New pledge subject/body</th><td>
                    <input type="text" name="email_pledge_subject_donor" value="<?php echo esc_attr($opt['email_pledge_subject_donor'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_pledge_body_donor" rows="6" class="large-text"><?php echo esc_textarea($opt['email_pledge_body_donor'] ?? ''); ?></textarea>
                </td></tr>
                <tr><th>Donor: Charge success subject/body</th><td>
                    <input type="text" name="email_charge_success_subject_donor" value="<?php echo esc_attr($opt['email_charge_success_subject_donor'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_charge_success_body_donor" rows="6" class="large-text"><?php echo esc_textarea($opt['email_charge_success_body_donor'] ?? ''); ?></textarea>
                </td></tr>
                <tr><th>Admin: Charge success subject/body</th><td>
                    <input type="text" name="email_charge_success_subject_admin" value="<?php echo esc_attr($opt['email_charge_success_subject_admin'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_charge_success_body_admin" rows="6" class="large-text"><?php echo esc_textarea($opt['email_charge_success_body_admin'] ?? ''); ?></textarea>
                </td></tr>
                <tr><th>Donor: Charge failed subject/body</th><td>
                    <input type="text" name="email_charge_fail_subject_donor" value="<?php echo esc_attr($opt['email_charge_fail_subject_donor'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_charge_fail_body_donor" rows="6" class="large-text"><?php echo esc_textarea($opt['email_charge_fail_body_donor'] ?? ''); ?></textarea>
                </td></tr>
                <tr><th>Admin: Charge failed subject/body</th><td>
                    <input type="text" name="email_charge_fail_subject_admin" value="<?php echo esc_attr($opt['email_charge_fail_subject_admin'] ?? ''); ?>" class="large-text"><br>
                    <textarea name="email_charge_fail_body_admin" rows="6" class="large-text"><?php echo esc_textarea($opt['email_charge_fail_body_admin'] ?? ''); ?></textarea>
                </td></tr>
            </table>
            <p><button class="button button-primary" name="gppf_save_settings" value="1">Save settings</button></p>
        </form>
    </div>
    <?php
}

/**
 * Verify Stripe account
 */
function gppf_verify_stripe($sk){
    if(empty($sk)) return array('ok'=>false,'err'=>'No Secret key set');
    $resp = wp_remote_get('https://api.stripe.com/v1/account', array(
        'headers' => array('Authorization' => 'Bearer '.$sk),
        'timeout' => 15,
    ));
    if(is_wp_error($resp)){
        return array('ok'=>false,'err'=>$resp->get_error_message());
    }
    $code = wp_remote_retrieve_response_code($resp);
    if($code !== 200){
        return array('ok'=>false,'err'=>'HTTP '.$code);
    }
    $body = json_decode(wp_remote_retrieve_body($resp), true);
    return array('ok'=>!empty($body['id']), 'acct'=> $body['id'] ?? '');
}
