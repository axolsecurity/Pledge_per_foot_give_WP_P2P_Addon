<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Replace {tags} in email templates
 */
function gppf_tags($text, $args){
    $rep = array('{site_name}' => get_bloginfo('name'));
    foreach ((array)$args as $k=>$v) {
        $rep['{'.$k.'}'] = (string)$v;
    }
    return strtr((string)$text, $rep);
}

/**
 * Send plain text email
 */
function gppf_send_email($to, $subject, $body){
    add_filter('wp_mail_content_type', function(){ return 'text/plain'; });
    $ok = wp_mail($to, $subject, $body);
    remove_filter('wp_mail_content_type', '__return_false');
    return $ok;
}

/**
 * Send admin + donor emails AFTER pledge meta is saved.
 * The form handler triggers: do_action('gppf_pledge_created', $post_id)
 */
add_action('gppf_pledge_created', function($post_id){
    if (get_post_type($post_id) !== 'ppf_pledge') return;
    if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) return;
    if (get_post_status($post_id) !== 'publish') return;

    // Prevent duplicate sends
    if (get_post_meta($post_id, '_gppf_created_emails_sent', true)) return;

    // Load settings
    $opt = get_option(defined('GPPF_OPTION') ? GPPF_OPTION : 'gppf_settings', array());

    // Gather meta fields
    $rate_raw     = (float) get_post_meta($post_id, '_gppf_rate', true);
    $feet_cap_raw = get_post_meta($post_id, '_gppf_feet_cap', true);
    $feet_cap     = ($feet_cap_raw === '' || $feet_cap_raw === null) ? 0 : (float) $feet_cap_raw;

    $args = array(
        'pledge_id'       => $post_id,
        'fundraiser_name' => get_post_meta($post_id, '_gppf_fundraiser_name', true),
        'donor_name'      => get_post_meta($post_id, '_gppf_donor_name', true),
        'donor_email'     => get_post_meta($post_id, '_gppf_donor_email', true),
        'rate'            => number_format($rate_raw, 2, '.', ''), // e.g. "0.10"
        'cap'             => $feet_cap,                            // default 0 if unset
    );

    /** ---- Admin Email ---- **/
    if (!empty($opt['admin_emails'])) {
        $to   = is_array($opt['admin_emails'])
            ? $opt['admin_emails']
            : array_map('trim', explode(',', $opt['admin_emails']));
        $subj = gppf_tags($opt['email_pledge_subject_admin'] ?? 'New pledge on {site_name} (#{pledge_id})', $args);
        $body = gppf_tags($opt['email_pledge_body_admin']    ?? "A new pledge was created.\n\nDonor: {donor_name}\nFundraiser: {fundraiser_name}\nRate: {rate} /ft\nCap: {cap}\nPledge ID: {pledge_id}\n", $args);
        gppf_send_email($to, $subj, $body);
    }

    /** ---- Donor Email ---- **/
    if (!empty($args['donor_email'])) {
        $subj = gppf_tags($opt['email_pledge_subject_donor'] ?? 'Thanks for your pledge on {site_name}', $args);
        $body = gppf_tags($opt['email_pledge_body_donor']    ?? "Hi {donor_name},\n\nThanks for pledging {rate} /ft.\nFundraiser: {fundraiser_name}\nCap: {cap}\nPledge ID: {pledge_id}\n", $args);
        gppf_send_email($args['donor_email'], $subj, $body);
    }

    update_post_meta($post_id, '_gppf_created_emails_sent', 1);
}, 10);

