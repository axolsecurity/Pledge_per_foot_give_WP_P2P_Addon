<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Inject "Pledge Per Foot" button next to Donate button on fundraiser pages.
 * Works by reading #p2p-app dataset for fundraiser id and then inserting a link to the pledge page slug.
 */
add_action('wp_enqueue_scripts', function(){
    $opt = get_option(GPPF_OPTION, array());
    $slug = !empty($opt['pledge_page_slug']) ? $opt['pledge_page_slug'] : 'per-foot-pledge';
    $data = array(
        'slug' => home_url('/'.$slug.'/'),
    );
    wp_register_script('gppf-button', plugins_url('public/button.js', dirname(__FILE__)), array(), GPPF_VER, true);
    wp_localize_script('gppf-button', 'GPPF_BTN', $data);
    wp_enqueue_script('gppf-button');
}, 99);
