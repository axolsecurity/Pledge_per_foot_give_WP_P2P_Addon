<?php
if (!defined('ABSPATH')) { exit; }

function gppf_admin_charges(){
    if(!current_user_can('manage_options')) return;

    // list pledges grouped by fundraiser_id
    $pledges = get_posts(array(
        'post_type' => 'ppf_pledge',
        'post_status' => 'publish',
        'numberposts' => -1,
    ));
    $by = array();
    foreach($pledges as $p){
        $fid = get_post_meta($p->ID, '_gppf_fundraiser_id', true);
        if(!$fid) $fid = 'unknown';
        $by[$fid][] = $p;
    }

    echo '<div class="wrap"><h1>Charges</h1>';
    echo '<p>Set the final feet per fundraiser and charge pledges accordingly.</p>';
    echo '<table class="widefat striped"><thead><tr><th>Fundraiser</th><th>Pledges</th><th>Final feet</th><th>Actions</th></tr></thead><tbody>';
    foreach($by as $fid => $posts){
        $name = get_post_meta($posts[0]->ID, '_gppf_fundraiser_name', true);
        $final = get_option('gppf_final_feet_'.$fid, '');
        echo '<tr>';
        printf('<td>%s (#%s)</td>', esc_html($name ?: 'Unknown'), esc_html($fid));
        printf('<td>%d</td>', count($posts));
        echo '<td>';
        echo '<form method="post" style="display:inline">';
        wp_nonce_field('gppf_save_final_feet_'.$fid);
        printf('<input type="number" name="gppf_final_feet" step="1" min="0" value="%s" style="width:120px"> ', esc_attr($final));
        printf('<input type="hidden" name="gppf_fid" value="%s">', esc_attr($fid));
        echo '<button class="button">Save</button>';
        echo '</form>';
        echo '</td>';
        echo '<td>';
        echo '<form method="post" style="display:inline">';
        wp_nonce_field('gppf_charge_'.$fid);
        printf('<input type="hidden" name="gppf_charge_fid" value="%s">', esc_attr($fid));
        echo '<button class="button button-primary">Charge ALL pledges</button>';
        echo '</form>';
        echo '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';

    // handle saves
    if(isset($_POST['gppf_fid']) && check_admin_referer('gppf_save_final_feet_'.$_POST['gppf_fid'])){
        $feet = max(0, intval($_POST['gppf_final_feet'] ?? 0));
        update_option('gppf_final_feet_'.sanitize_text_field($_POST['gppf_fid']), $feet);
        echo '<div class="updated"><p>Saved.</p></div>';
    }

    // handle charges (demo placeholder; assumes $0.50 min)
    if(isset($_POST['gppf_charge_fid']) && check_admin_referer('gppf_charge_'.$_POST['gppf_charge_fid'])){
        $fid = sanitize_text_field($_POST['gppf_charge_fid']);
        $feet = intval(get_option('gppf_final_feet_'.$fid, 0));
        $opt = get_option(GPPF_OPTION, array());
        $pledges = get_posts(array(
            'post_type'=>'ppf_pledge','post_status'=>'publish','numberposts'=>-1,
            'meta_key'=>'_gppf_fundraiser_id','meta_value'=>$fid
        ));
        echo '<div class="notice notice-info"><p>Processing '.count($pledges).' pledges for fundraiser #'.esc_html($fid).' ('.$feet.' ft)...</p></div>';
        foreach($pledges as $p){
            $rate = floatval(get_post_meta($p->ID,'_gppf_rate',true));
            $cap  = floatval(get_post_meta($p->ID,'_gppf_cap',true));
            $amount = $rate * $feet;
            if($cap>0 && $amount>$cap) $amount = $cap;
            $amount = round($amount, 2);
            $args = array(
                'pledge_id'=>$p->ID,
                'fundraiser_name'=>get_post_meta($p->ID,'_gppf_fundraiser_name',true),
                'donor_name'=>get_post_meta($p->ID,'_gppf_donor_name',true),
                'donor_email'=>get_post_meta($p->ID,'_gppf_donor_email',true),
                'rate'=>$rate, 'cap'=>$cap, 'feet'=>$feet, 'amount'=>$amount,
                'payment_intent'=>''
            );
            if($amount < 0.5){
                $args['error'] = 'Amount below minimum charge';
                gppf_notify_charge_failure($args, $opt);
                continue;
            }
            // Here you would create a Stripe PaymentIntent using saved customer/payment_method (omitted in lite build)
            // For now, mark as simulated success.
            $args['payment_intent'] = 'sim_pi_'.wp_generate_password(10, false);
            gppf_notify_charge_success($args, $opt);
            update_post_meta($p->ID, '_gppf_last_charged', current_time('mysql'));
            update_post_meta($p->ID, '_gppf_last_amount', $amount);
        }
    }
}

function gppf_notify_charge_success($args, $opt){
    // donor
    if(!empty($args['donor_email'])){
        $s = gppf_tags($opt['email_charge_success_subject_donor'] ?? '', $args);
        $b = gppf_tags($opt['email_charge_success_body_donor'] ?? '', $args);
        gppf_send_email($args['donor_email'], $s, $b);
    }
    // admin
    if(!empty($opt['admin_emails'])){
        $to = array_map('trim', explode(',', $opt['admin_emails']));
        $s = gppf_tags($opt['email_charge_success_subject_admin'] ?? '', $args);
        $b = gppf_tags($opt['email_charge_success_body_admin'] ?? '', $args);
        gppf_send_email($to, $s, $b);
    }
}

function gppf_notify_charge_failure($args, $opt){
    // donor
    if(!empty($args['donor_email'])){
        $s = gppf_tags($opt['email_charge_fail_subject_donor'] ?? '', $args);
        $b = gppf_tags($opt['email_charge_fail_body_donor'] ?? '', $args);
        gppf_send_email($args['donor_email'], $s, $b);
    }
    // admin
    if(!empty($opt['admin_emails'])){
        $to = array_map('trim', explode(',', $opt['admin_emails']));
        $s = gppf_tags($opt['email_charge_fail_subject_admin'] ?? '', $args);
        $b = gppf_tags($opt['email_charge_fail_body_admin'] ?? '', $args);
        gppf_send_email($to, $s, $b);
    }
}
