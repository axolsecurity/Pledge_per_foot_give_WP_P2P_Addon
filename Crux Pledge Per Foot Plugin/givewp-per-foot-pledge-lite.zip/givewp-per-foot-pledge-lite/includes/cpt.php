<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Register pledge CPT
 */
add_action('init', function() {
    $labels = array(
        'name'          => 'Per-Foot Pledges',
        'singular_name' => 'Per-Foot Pledge',
        'add_new'       => 'Add Pledge',
        'add_new_item'  => 'Add New Pledge',
        'edit_item'     => 'Edit Pledge',
        'new_item'      => 'New Pledge',
        'view_item'     => 'View Pledge',
        'search_items'  => 'Search Pledges',
        'not_found'     => 'No pledges found',
        'menu_name'     => 'Per-Foot Pledges'
    );
    register_post_type('ppf_pledge', array(
        'labels'         => $labels,
        'public'         => false,
        'show_ui'        => true,
        'show_in_menu'   => false, // we add our own top-level menu
        'supports'       => array('title'),
        'capability_type'=> 'post',
    ));
});

/**
 * Editable "Pledge Details" meta box
 */
add_action('add_meta_boxes', function(){
    add_meta_box('gppf_details', 'Pledge Details', function($post){
        // Nonce
        wp_nonce_field('gppf_details_save', 'gppf_details_nonce');

        // Read current values
        $donor_name      = get_post_meta($post->ID, '_gppf_donor_name', true);
        $donor_email     = get_post_meta($post->ID, '_gppf_donor_email', true);
        $donor_phone     = get_post_meta($post->ID, '_gppf_donor_phone', true);
        $rate            = get_post_meta($post->ID, '_gppf_rate', true);
        $feet_cap_raw    = get_post_meta($post->ID, '_gppf_feet_cap', true);
        $feet_cap        = ($feet_cap_raw === '' || $feet_cap_raw === null) ? 0 : $feet_cap_raw; // show 0 if empty
        $dollar_cap      = get_post_meta($post->ID, '_gppf_cap', true); // legacy; shown read-only
        $fundraiser_id   = get_post_meta($post->ID, '_gppf_fundraiser_id', true);
        $fundraiser_name = get_post_meta($post->ID, '_gppf_fundraiser_name', true);

        echo '<table class="form-table">';

        echo '<tr><th><label for="gppf_donor_name">Donor Name</label></th><td>';
        printf('<input type="text" id="gppf_donor_name" name="gppf_donor_name" value="%s" class="regular-text" required>', esc_attr($donor_name));
        echo '</td></tr>';

        echo '<tr><th><label for="gppf_donor_email">Donor Email</label></th><td>';
        printf('<input type="email" id="gppf_donor_email" name="gppf_donor_email" value="%s" class="regular-text">', esc_attr($donor_email));
        echo '</td></tr>';

        echo '<tr><th><label for="gppf_donor_phone">Donor Phone</label></th><td>';
        printf('<input type="text" id="gppf_donor_phone" name="gppf_donor_phone" value="%s" class="regular-text">', esc_attr($donor_phone));
        echo '</td></tr>';

        echo '<tr><th><label for="gppf_rate">Rate ($/ft)</label></th><td>';
        printf('<input type="number" step="0.01" min="0" id="gppf_rate" name="gppf_rate" value="%s" class="small-text" required>', esc_attr($rate));
        echo ' <span class="description">Dollar amount per foot</span></td></tr>';

        echo '<tr><th><label for="gppf_feet_cap">Footage Cap (ft)</label></th><td>';
        printf('<input type="number" step="1" min="0" id="gppf_feet_cap" name="gppf_feet_cap" value="%s" class="small-text">', esc_attr($feet_cap));
        echo ' <span class="description">0 = no cap</span></td></tr>';

        // Keep legacy Cap ($) visible but read-only (your system now uses feet-cap)
        echo '<tr><th>Cap ($)</th><td>';
        printf('<input type="text" value="%s" class="regular-text" readonly>', esc_attr($dollar_cap));
        echo ' <span class="description">Legacy field; computed/unused when using feet caps</span></td></tr>';

        echo '<tr><th><label for="gppf_fundraiser_name">Fundraiser</label></th><td>';
        printf('<input type="text" id="gppf_fundraiser_name" name="gppf_fundraiser_name" value="%s" class="regular-text">', esc_attr($fundraiser_name));
        echo '</td></tr>';

        echo '<tr><th><label for="gppf_fundraiser_id">Fundraiser ID</label></th><td>';
        printf('<input type="number" step="1" min="0" id="gppf_fundraiser_id" name="gppf_fundraiser_id" value="%s" class="small-text">', esc_attr($fundraiser_id));
        echo '</td></tr>';

        echo '</table>';
    }, 'ppf_pledge', 'normal', 'high');
});

/**
 * Save handler for the editable meta box (fixed: no infinite loop)
 */
function gppf_save_pledge_meta($post_id){
    static $gppf_updating_title = false;

    // Basic guards
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (get_post_type($post_id) !== 'ppf_pledge') return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (empty($_POST['gppf_details_nonce']) || !wp_verify_nonce($_POST['gppf_details_nonce'], 'gppf_details_save')) return;

    // Sanitize inputs
    $donor_name      = isset($_POST['gppf_donor_name'])      ? sanitize_text_field(wp_unslash($_POST['gppf_donor_name']))      : '';
    $donor_email     = isset($_POST['gppf_donor_email'])     ? sanitize_email(wp_unslash($_POST['gppf_donor_email']))           : '';
    $donor_phone     = isset($_POST['gppf_donor_phone'])     ? sanitize_text_field(wp_unslash($_POST['gppf_donor_phone']))      : '';
    $rate            = isset($_POST['gppf_rate'])            ? (float) wp_unslash($_POST['gppf_rate'])                           : 0;
    $feet_cap_val    = isset($_POST['gppf_feet_cap'])        ? wp_unslash($_POST['gppf_feet_cap'])                               : '';
    $feet_cap        = ($feet_cap_val === '' || $feet_cap_val === null) ? 0 : (float) $feet_cap_val; // store 0 if empty
    $fundraiser_name = isset($_POST['gppf_fundraiser_name']) ? sanitize_text_field(wp_unslash($_POST['gppf_fundraiser_name']))   : '';
    $fundraiser_id   = isset($_POST['gppf_fundraiser_id'])   ? intval($_POST['gppf_fundraiser_id'])                              : 0;

    // Persist meta
    update_post_meta($post_id, '_gppf_donor_name',      $donor_name);
    if ($donor_email !== '') update_post_meta($post_id, '_gppf_donor_email', $donor_email);
    update_post_meta($post_id, '_gppf_donor_phone',     $donor_phone);
    update_post_meta($post_id, '_gppf_rate',            $rate);
    update_post_meta($post_id, '_gppf_feet_cap',        $feet_cap);
    update_post_meta($post_id, '_gppf_fundraiser_name', $fundraiser_name);
    update_post_meta($post_id, '_gppf_fundraiser_id',   $fundraiser_id);

    // Keep post_title in sync without looping
    $title_bits = array_filter([
        $donor_name,
        $fundraiser_name ?: ( $fundraiser_id ? "Fundraiser #{$fundraiser_id}" : '' ),
        $rate ? sprintf('$%.2f/ft', $rate) : '',
    ]);
    $new_title  = implode(' – ', $title_bits);
    $old_title  = get_post_field('post_title', $post_id);

    if ($new_title && $new_title !== $old_title) {
        if ($gppf_updating_title) return; // re-entrancy guard
        $gppf_updating_title = true;
        wp_update_post(['ID' => $post_id, 'post_title' => $new_title]);
        $gppf_updating_title = false;
    }
}
add_action('save_post_ppf_pledge', 'gppf_save_pledge_meta', 10);

/**
 * Admin columns (unchanged)
 */
add_filter('manage_ppf_pledge_posts_columns', function($cols){
    $cols['gppf_donor']      = 'Donor';
    $cols['gppf_rate']       = '$/ft';
    $cols['gppf_cap']        = 'Cap';
    $cols['gppf_feet']       = 'Footage Cap';
    $cols['gppf_fundraiser'] = 'Fundraiser';
    return $cols;
});

add_action('manage_ppf_pledge_posts_custom_column', function($col, $post_id){
    if($col==='gppf_donor'){
        $n = get_post_meta($post_id, '_gppf_donor_name', true);
        $e = get_post_meta($post_id, '_gppf_donor_email', true);
        echo esc_html($n).' &lt;'.esc_html($e).'&gt;';
    } elseif($col==='gppf_rate'){
        echo esc_html(get_post_meta($post_id, '_gppf_rate', true));
    } elseif($col==='gppf_cap'){
        echo esc_html(get_post_meta($post_id, '_gppf_cap', true));
    } elseif($col==='gppf_feet'){
        echo esc_html(get_post_meta($post_id, '_gppf_feet_cap', true));
    } elseif($col==='gppf_fundraiser'){
        $name = get_post_meta($post_id, '_gppf_fundraiser_name', true);
        $fid  = get_post_meta($post_id, '_gppf_fundraiser_id', true);
        if($fid){
            $url = home_url('/campaign/verts-for-vets-competition/fundraiser/'.$fid.'/');
            printf('<a href="%s" target="_blank">%s</a>', esc_url($url), esc_html($name?:('Fundraiser #'.$fid)));
        } else {
            echo esc_html($name);
        }
    }
}, 10, 2);

/**
 * Top-level admin menu + subpages
 */
add_action('admin_menu', function(){
    add_menu_page('Per-Foot Pledges', 'Per-Foot Pledges', 'manage_options', 'gppf', 'gppf_admin_dashboard', 'dashicons-chart-area', 58);
    add_submenu_page('gppf', 'Pledges', 'Pledges', 'manage_options', 'edit.php?post_type=ppf_pledge');
    add_submenu_page('gppf', 'Charges', 'Charges', 'manage_options', 'gppf-charges', 'gppf_admin_charges');
    add_submenu_page('gppf', 'Settings', 'Settings', 'manage_options', 'gppf-settings', 'gppf_admin_settings');
});

function gppf_admin_dashboard(){
    echo '<div class="wrap"><h1>Per-Foot Pledges</h1><p>Use the submenu to view Pledges, run Charges, or configure Settings.</p></div>';
}

