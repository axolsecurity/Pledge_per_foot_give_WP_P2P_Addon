(function(){
  function getFundraiserId(){
    var app = document.getElementById('p2p-app');
    if(!app) return null;
    try{
      var data = app.getAttribute('data-fundraiser');
      if(!data) return null;
      var obj = JSON.parse(data);
      return obj && obj.id ? obj.id : null;
    }catch(e){ return null; }
  }
  function insertButton(){
    var fid = getFundraiserId();
    if(!fid) return;
    // Look for existing donate button container
    var host = document.querySelector('#give-p2p-host');
    var donate = document.querySelector('a[href$="/donate"], a[class*="give-button"]');
    // If inside shadow root (web component), try deeper:
    if(host && host.shadowRoot){
      donate = host.shadowRoot.querySelector('a[href*="/fundraiser/'+fid+'/donate"]') || host.shadowRoot.querySelector('a[class*="give-button"]');
    }
    if(!donate) return;
    // avoid duplicates
    if(document.querySelector('a.gppf-pledge-btn') || (host && host.shadowRoot && host.shadowRoot.querySelector('a.gppf-pledge-btn'))) return;

    var href = (GPPF_BTN && GPPF_BTN.slug ? GPPF_BTN.slug : '/per-foot-pledge/') + '?fundraiser_id=' + encodeURIComponent(fid);

    var btn = document.createElement('a');
    btn.className = (donate.getAttribute('class') || '') + ' gppf-pledge-btn';
    btn.setAttribute('part', donate.getAttribute('part') || 'give-button give-button--primary give-button--medium');
    btn.style.minWidth = '200px';
    btn.href = href;
    btn.innerHTML = donate.innerHTML.replace(/Donate Now/i, 'Pledge Per Foot');

    // Insert after donate
    if(donate.parentNode){
      donate.parentNode.appendChild(btn);
    } else if(host && host.shadowRoot){
      donate.insertAdjacentElement('afterend', btn);
    }
  }
  function ready(fn){ if(document.readyState !== 'loading'){ fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  ready(function(){
    insertButton();
    // Some P2P renders asynchronously; try a few times
    var tries = 0;
    var iv = setInterval(function(){
      tries++;
      insertButton();
      if(tries>20) clearInterval(iv);
    }, 500);
  });
})();