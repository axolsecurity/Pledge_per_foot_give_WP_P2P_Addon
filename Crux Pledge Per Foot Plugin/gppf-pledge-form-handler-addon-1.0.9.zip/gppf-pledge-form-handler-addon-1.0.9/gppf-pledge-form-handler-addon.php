<?php
/**
 * Plugin Name: GPPF Pledge Form Handler (Addon)
 * Description: Handles the pledge form, auto-detects fields, shows inline messages, removes $ Cap from admin UI/storage, and ensures only the fundraiser name shows on the form.
 * Version: 1.0.9
 * Author: Axolsoft, LLC
 * License: GPL-2.0-or-later
 * Requires at least: 5.6
 * Requires PHP: 7.4
 */

if ( ! defined('ABSPATH') ) { exit; }

define('GPPF_PH_ADDON_VER', '1.0.8');
define('GPPF_PH_ADDON_URL', plugin_dir_url(__FILE__));
define('GPPF_PH_ADDON_PATH', plugin_dir_path(__FILE__));

add_action('plugins_loaded', function () {
    require_once GPPF_PH_ADDON_PATH . 'includes/gppf-pledge-form-handler.php';
    require_once GPPF_PH_ADDON_PATH . 'includes/gppf-admin-columns.php';
    require_once GPPF_PH_ADDON_PATH . 'includes/gppf-pledge-settings.php';
});

// Front-end script (messages + fundraiser display cleanup)
add_action('wp_enqueue_scripts', function () {
    wp_register_script('gppf-ph-ui', GPPF_PH_ADDON_URL . 'assets/js/ui.js', array(), GPPF_PH_ADDON_VER, true);
    wp_localize_script('gppf-ph-ui', 'GPPF_PH', array(
        'thankyouHtml' => gppf_ph_get_thankyou_html(),
    ));
    wp_enqueue_script('gppf-ph-ui');
});

// Admin: hide Cap($) field in single edit screen
add_action('admin_enqueue_scripts', function($hook){
    if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) return;
    $screen = get_current_screen();
    if ( ! $screen || $screen->post_type !== 'ppf_pledge' ) return;
    $css = '.gppf-hide { display:none !important; }';
    wp_add_inline_style('wp-admin', $css);
    add_action('admin_print_footer_scripts', function(){
        ?>
        <script>
        (function(){
          // Hide any table row in meta boxes where the header cell text is exactly "Cap ($)"
          var rows = document.querySelectorAll('.postbox table tr');
          rows.forEach(function(tr){
            var th = tr.querySelector('th, .label');
            if (!th) return;
            var txt = (th.textContent||'').trim().toLowerCase();
            if (txt === 'cap ($)'.toLowerCase() || txt === 'cap ($)'.toLowerCase() || txt === 'cap ($)'.toLowerCase()) {
              tr.style.display = 'none';
            }
            if (txt === 'cap ($)' || txt === 'cap ($)') {
              tr.style.display = 'none';
            }
            if (txt === 'cap ($)'.toLowerCase() || txt === 'cap ($)') {
              tr.style.display = 'none';
            }
            // Fallback: if header equals "Cap" exactly
            if (txt === 'cap') { tr.style.display = 'none'; }
          });
        })();
        </script>
        <?php
    });
});

function gppf_ph_get_thankyou_html() {
    $html = get_option('gppf_ph_thankyou_html');
    if ( ! $html ) {
        $html = '<div class="gppf-thanks" role="status" aria-live="polite"><h3>Thank you for your pledge!</h3><p>You should receive a confirmation email shortly.</p></div>';
    }
    return wp_kses_post($html);
}
