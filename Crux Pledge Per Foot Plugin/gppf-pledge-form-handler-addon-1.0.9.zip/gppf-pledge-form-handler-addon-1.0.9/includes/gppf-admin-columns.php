<?php
if ( ! defined('ABSPATH') ) { exit; }

// Remove the "Cap ($)" column from the list; keep "Footage Cap". Also keep Phone column from v1.0.7.
add_filter('manage_edit-ppf_pledge_columns', function($cols){
    // Remove any column whose label equals "Cap ($)" or exactly "Cap"
    foreach ($cols as $key => $label) {
        if (is_string($label)) {
            $l = strtolower($label);
            if ($l === 'cap ($)' || $l === 'cap' || $l === 'cap ($)') {
                unset($cols[$key]);
            }
        }
    }
    // Ensure Phone column exists after Title
    if (!isset($cols['gppf_phone'])) {
        $new = array();
        foreach ($cols as $k=>$v) {
            $new[$k] = $v;
            if ($k === 'title') { $new['gppf_phone'] = __('Phone'); }
        }
        $cols = $new;
    }
    return $cols;
}, 20);

add_action('manage_ppf_pledge_posts_custom_column', function($col, $post_id){
    if ($col === 'gppf_phone') {
        $phone = get_post_meta($post_id, '_gppf_donor_phone', true);
        echo esc_html($phone);
    }
}, 10, 2);
