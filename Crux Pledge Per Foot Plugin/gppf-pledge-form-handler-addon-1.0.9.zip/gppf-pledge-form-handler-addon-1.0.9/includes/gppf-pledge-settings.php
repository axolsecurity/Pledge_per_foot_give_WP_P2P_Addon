<?php
if ( ! defined('ABSPATH') ) { exit; }

add_action('admin_menu', function () {
    add_options_page(
        'GPPF Pledge Handler',
        'GPPF Pledge Handler',
        'manage_options',
        'gppf-pledge-handler',
        'gppf_ph_settings_page'
    );
});

add_action('admin_init', function () {
    register_setting('gppf_ph_settings', 'gppf_ph_thankyou_html');
    add_settings_section('gppf_ph_main', 'Thank You Message', '__return_null', 'gppf-pledge-handler');
    add_settings_field('gppf_ph_thankyou_html', 'Thank You HTML', 'gppf_ph_thankyou_field', 'gppf-pledge-handler', 'gppf_ph_main');
});

function gppf_ph_thankyou_field() {
    $val = get_option('gppf_ph_thankyou_html', '<div class="gppf-thanks" role="status" aria-live="polite"><h3>Thank you for your pledge!</h3><p>You should receive a confirmation email shortly.</p></div>');
    echo '<textarea name="gppf_ph_thankyou_html" rows="8" style="width:100%;">' . esc_textarea($val) . '</textarea>';
    echo '<p class="description">This HTML replaces the pledge form when a pledge is successfully submitted.</p>';
}

function gppf_ph_settings_page() {
    ?>
    <div class="wrap">
        <h1>GPPF Pledge Handler</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('gppf_ph_settings');
            do_settings_sections('gppf-pledge-handler');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
