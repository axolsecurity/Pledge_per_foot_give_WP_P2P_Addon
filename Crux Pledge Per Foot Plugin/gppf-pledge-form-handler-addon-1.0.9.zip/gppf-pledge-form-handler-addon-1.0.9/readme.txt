=== GPPF Pledge Form Handler (Addon) ===
Contributors: chatgpt
Requires at least: 5.6
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.8
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Removes $ Cap entirely (storage + admin UI), keeps only Footage Cap. Also cleans the front-end to show only the fundraiser name (no "Fundraiser #2"). All prior fixes/features retained.

== 1.0.8 ==
* Storage: never saves `_gppf_cap` and deletes it on new pledges.
* Admin list: removes the "Cap ($)" column; keeps "Footage Cap".
* Admin edit screen: hides the "Cap ($)" field.
* Front-end: replaces any "Fundraiser #X" text with a clean name-only line.
