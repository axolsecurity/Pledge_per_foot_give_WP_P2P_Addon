(function(){
  function qs(name){
    var m = new RegExp('[?&]'+name+'=([^&]+)').exec(window.location.search);
    return m && decodeURIComponent(m[1].replace(/\+/g, ' '));
  }
  function findForm(){
    return document.querySelector('form[data-gppf-form]') ||
           Array.prototype.find.call(document.querySelectorAll('form'), function(f){
             return f.querySelector('input[name="action"][value="gppf_create_pledge"]');
           });
  }
  function showError(form, msg){
    var safe = document.createElement('div');
    safe.setAttribute('role','alert');
    safe.setAttribute('aria-live','assertive');
    safe.className = 'gppf-error';
    safe.style.background = '#fee';
    safe.style.border = '1px solid #f99';
    safe.style.padding = '12px';
    safe.style.marginBottom = '12px';
    safe.style.borderRadius = '6px';
    safe.textContent = msg;
    form.parentNode.insertBefore(safe, form);
    window.scrollTo({ top: safe.getBoundingClientRect().top + window.scrollY - 40, behavior: 'smooth'});
  }
  function showThanks(form, html){
    var wrap = form.parentElement; if (!wrap) return;
    wrap.innerHTML = html || (window.GPPF_PH && GPPF_PH.thankyouHtml) || '<div class="gppf-thanks"><h3>Thank you!</h3></div>';
    window.scrollTo({ top: wrap.getBoundingClientRect().top + window.scrollY - 40, behavior: 'smooth'});
  }

  function ensureMirrorsAndCleanFundraiser(form){
    // Email
    if (!form.querySelector('input[name="email"], input[name="donor_email"], input[name="email_address"]')) {
      var emailInput = form.querySelector('input[type="email"]');
      if (emailInput) {
        var hiddenEmail = document.createElement('input');
        hiddenEmail.type='hidden'; hiddenEmail.name='email'; hiddenEmail.value = emailInput.value || '';
        form.appendChild(hiddenEmail);
        form.addEventListener('input', function(e){ if (e.target === emailInput) hiddenEmail.value = emailInput.value; });
      }
    }
    // Phone
    if (!form.querySelector('input[name="phone"], input[name="donor_phone"]')) {
      var tel = form.querySelector('input[type="tel"]');
      if (tel) {
        var hiddenTel = document.createElement('input');
        hiddenTel.type='hidden'; hiddenTel.name='phone'; hiddenTel.value = tel.value || '';
        form.appendChild(hiddenTel);
        form.addEventListener('input', function(e){ if (e.target === tel) hiddenTel.value = tel.value; });
      }
    }
    // Rate
    if (!form.querySelector('input[name="rate_per_foot"], input[name="rate"], input[name="pledge_rate"]')) {
      var rateInput = null;
      var candidates = form.querySelectorAll('input[type="number"], input[type="text"]');
      candidates.forEach(function(inp){
        if (rateInput) return;
        var ph = (inp.getAttribute('placeholder')||'').toLowerCase();
        if (ph.indexOf('per foot') !== -1 || ph.indexOf('$ per foot') !== -1) { rateInput = inp; return; }
        var id = inp.id;
        if (id) {
          var label = form.querySelector('label[for="'+CSS.escape(id)+'"]');
          if (label && label.textContent.toLowerCase().indexOf('per foot') !== -1) { rateInput = inp; return; }
        }
        var nm = (inp.name||'').toLowerCase();
        if (nm && (nm.indexOf('rate')!==-1 || nm.indexOf('amount')!==-1) && nm.indexOf('cap')===-1 && nm.indexOf('feet')===-1) { rateInput = inp; return; }
      });
      if (rateInput) {
        var hiddenRate = document.createElement('input');
        hiddenRate.type='hidden'; hiddenRate.name='rate_per_foot'; hiddenRate.value = rateInput.value || '';
        form.appendChild(hiddenRate);
        form.addEventListener('input', function(e){ if (e.target === rateInput) hiddenRate.value = rateInput.value; });
      }
    }
    // Feet cap (single cap input → treat as feet cap)
    if (!form.querySelector('input[name="feet_cap"]')) {
      var capCand = Array.prototype.find.call(form.querySelectorAll('input[type="number"], input[type="text"]'), function(inp){
        var nm=(inp.name||'').toLowerCase(); var ph=(inp.placeholder||'').toLowerCase();
        return nm.indexOf('cap')!==-1 || ph.indexOf('cap')!==-1;
      });
      if (capCand) {
        var hiddenFeetCap = document.createElement('input');
        hiddenFeetCap.type='hidden'; hiddenFeetCap.name='feet_cap'; hiddenFeetCap.value = capCand.value || '';
        form.appendChild(hiddenFeetCap);
        form.addEventListener('input', function(e){ if (e.target === capCand) hiddenFeetCap.value = capCand.value; });
      }
    }
    // Name single-field
    if (!form.querySelector('input[name="first_name"], input[name="last_name"]')) {
      var nameInput = form.querySelector('input[name="name"], input[name="full_name"], input[name="your-name"], input[name="your_name"]');
      if (nameInput) {
        var hidden = document.createElement('input');
        hidden.type='hidden'; hidden.name='donor_name'; hidden.value = nameInput.value || '';
        form.appendChild(hidden);
        form.addEventListener('input', function(e){ if (e.target === nameInput) hidden.value = nameInput.value; });
      }
    }
    // Fundraiser from localStorage + URL
    try {
      var stored = localStorage.getItem('gppf_fundraiser');
      var fname = null, fid = null;
      if (stored) { var obj = JSON.parse(stored)||{}; fname = obj.name || null; fid = obj.id || null; }
      var url = new URL(window.location.href);
      if (!fid) fid = url.searchParams.get('fundraiser_id');
      if (!fname) fname = url.searchParams.get('fundraiser_name');

      if (fid && !form.querySelector('input[name="fundraiser_id"]')) {
        var hid = document.createElement('input'); hid.type='hidden'; hid.name='fundraiser_id'; hid.value = fid; form.appendChild(hid);
      }
      if (fname && !form.querySelector('input[name="fundraiser_name"]')) {
        var hidn = document.createElement('input'); hidn.type='hidden'; hidn.name='fundraiser_name'; hidn.value = fname; form.appendChild(hidn);
      }

      // Clean up any "Fundraiser #X" text on the page; prefer showing only the name
      if (fname) {
        var nodes = document.querySelectorAll('body *');
        nodes.forEach(function(el){
          if (el.children.length === 0) {
            var t = (el.textContent||'').trim();
            if (/Fundraiser\s*#\d+/i.test(t)) {
              // If the line also contains a name, keep the name; else replace with "Pledging for: {name}"
              if (t.indexOf(fname) === -1) {
                el.textContent = 'Pledging for: ' + fname;
              } else {
                el.textContent = t.replace(/Fundraiser\s*#\d+\s*[-–—]?\s*/i, '');
              }
            }
          }
        });
      }
    } catch(e){}
  }

  document.addEventListener('DOMContentLoaded', function(){
    var form = findForm();
    if (!form) return;
    ensureMirrorsAndCleanFundraiser(form);

    var state = qs('gppf');
    if (state === 'error') {
      var msg = qs('gppf_msg') || 'Something went wrong. Please try again.';
      showError(form, msg);
    } else if (state === 'thanks') {
      showThanks(form, (window.GPPF_PH && GPPF_PH.thankyouHtml));
    }
  });
})();