(function(){
  function ready(fn){ if(document.readyState!=='loading'){fn()} else document.addEventListener('DOMContentLoaded', fn); }
  function parseFundraiser(){
    var host = document.getElementById('p2p-app');
    if (!host) return null;
    try{
      var data = host.getAttribute('data-fundraiser');
      if (!data) return null;
      var obj = JSON.parse(data);
      return {
        id: (obj && obj.id) ? String(obj.id) : null,
        name: (obj && obj.fundraiser_name) ? String(obj.fundraiser_name) : null
      };
    }catch(e){ return null; }
  }
  function store(info){
    try{
      if (!info) return;
      var payload = { t: Date.now(), id: info.id || null, name: info.name || null };
      localStorage.setItem('gppf_fundraiser', JSON.stringify(payload));
    }catch(e){}
  }
  ready(function(){
    var info = parseFundraiser();
    if (info && (info.id || info.name)) store(info);
  });
})();