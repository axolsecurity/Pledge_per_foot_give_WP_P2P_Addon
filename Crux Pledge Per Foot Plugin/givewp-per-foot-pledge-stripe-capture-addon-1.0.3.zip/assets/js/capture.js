(function(){
  function ready(fn){ if(document.readyState!=='loading'){fn()} else document.addEventListener('DOMContentLoaded', fn); }
  function qs(sel,root){ return (root||document).querySelector(sel); }
  function qsa(sel,root){ return (root||document).querySelectorAll(sel); }
  function formMatches(f){ return !!(qs('input[name="gppf_amount_per_foot"], input[name="ppf_amount_per_foot"]', f)); }
  function findFormNow(){ var forms = qsa('form'); for (var i=0;i<forms.length;i++){ if(formMatches(forms[i])) return forms[i]; } return null; }
  function getStoredFundraiser(){
    try{ var raw = localStorage.getItem('gppf_fundraiser'); if (!raw) return null; var obj = JSON.parse(raw);
      if (!obj || (Date.now() - (obj.t||0) > 1000*60*60*24*7)) return null; return obj; }catch(e){ return null; } }
  function ensureFundraiserName(){
    try{
      var url = new URL(window.location.href);
      var fname = url.searchParams.get('fundraiser_name');
      if(!fname){
        var fn = url.searchParams.get('fn')||''; var ln = url.searchParams.get('ln')||''; if (fn || ln) fname = (fn+' '+ln).trim();
      }
      if(!fname){ var stored = getStoredFundraiser(); if (stored && stored.name) fname = stored.name; }
      if(!fname) return;
      var candidates = qsa('*'); var rx = /fundraiser\\s*#\\s*\\d+/i;
      for (var i=0;i<candidates.length;i++){ var el = candidates[i];
        if (el.childElementCount === 0 && rx.test(el.textContent || '')){ el.textContent = fname; } }
      var form = findFormNow();
      if (form && !qs('input[name="gppf_fundraiser_name"]', form)){ var hid = document.createElement('input');
        hid.type='hidden'; hid.name='gppf_fundraiser_name'; hid.value=fname; form.appendChild(hid); }
    }catch(e){}
  }
  function mountStripeCard(form){
    if (!window.GPPF_SC_VARS) { console.error('GPPF_SC: vars missing'); return; }
    if (!GPPF_SC_VARS.pk) {
      console.error('GPPF_SC: Stripe publishable key missing');
      var warn = document.createElement('div'); warn.className = 'gppf-sc-errors';
      warn.textContent = 'Stripe is not configured (no publishable key detected).'; form.appendChild(warn); return; }
    if (qs('#gppf-sc-card', form)) return;
    var cardRow = document.createElement('div'); cardRow.className = 'gppf-sc-card';
    cardRow.innerHTML = '<label>Card <span class="gppf-sc-req">*</span></label><div id="gppf-sc-card"></div><div class="gppf-sc-errors" role="alert" aria-live="polite"></div>';
    var submit = qs('button[type="submit"], input[type="submit"]', form);
    if (submit && submit.parentNode && submit.parentNode.parentNode){ submit.parentNode.parentNode.insertBefore(cardRow, submit.parentNode); }
    else { form.appendChild(cardRow); }
    var pm = document.createElement('input'); pm.type='hidden'; pm.name='gppf_payment_method';
    var cust = document.createElement('input'); cust.type='hidden'; cust.name='gppf_stripe_customer'; form.appendChild(pm); form.appendChild(cust);
    var stripe; try { stripe = Stripe(GPPF_SC_VARS.pk); } catch(e){ qs('.gppf-sc-errors', cardRow).textContent = 'Stripe initialization failed.'; console.error(e); return; }
    var elements = stripe.elements(); var card = elements.create('card', {}); card.mount('#gppf-sc-card');
    function getVal(name){ var el = qs('input[name="'+name+'"]', form); return el ? (el.value||'').trim() : ''; }
    function setupIntent(email, name){
      var fd = new FormData(); fd.append('action','gppf_sc_setup'); fd.append('nonce', GPPF_SC_VARS.nonce);
      fd.append('email', email); fd.append('name', name);
      return fetch(GPPF_SC_VARS.ajax, { method:'POST', body: fd, credentials:'same-origin' })
        .then(function(r){ return r.json(); })
        .then(function(j){ if (!j || !j.success) { throw new Error(j && j.data && j.data.message ? j.data.message : 'SetupIntent failed'); } return j.data; });
    }
    var submitting = false;
    form.addEventListener('submit', function(ev){
      if (submitting) return; ev.preventDefault();
      var email = getVal('gppf_email') || getVal('email');
      var first = getVal('gppf_first_name') || getVal('first_name') || '';
      var last  = getVal('gppf_last_name')  || getVal('last_name')  || '';
      var name  = (first + ' ' + last).trim() || email || 'Pledge Donor';
      var errorBox = qs('.gppf-sc-errors', cardRow); errorBox.textContent = '';
      setupIntent(email, name).then(function(data){
        return stripe.confirmCardSetup(data.client_secret, {
          payment_method: { card: card, billing_details: { name: name, email: email || null } }
        }).then(function(res){
          if (res.error) throw res.error;
          pm.value = res.setupIntent.payment_method; cust.value = data.customer; submitting = true; form.submit();
        });
      }).catch(function(err){
        errorBox.textContent = (err && err.message) ? err.message : String(err);
        console.error('GPPF_SC submit error:', err);
      });
    }, true);
  }
  function init(){
    ensureFundraiserName();
    var booted = false;
    function boot(){ if (booted) return; var f = findFormNow(); if (f){ booted = true; mountStripeCard(f); } }
    boot();
    var obs = new MutationObserver(function(){ boot(); });
    obs.observe(document.documentElement, {childList:true, subtree:true});
    var tries = 0; var iv = setInterval(function(){ if (booted) { clearInterval(iv); return; } tries++; boot(); if (tries > 40) clearInterval(iv); }, 500);
  }
  ready(init);
})();