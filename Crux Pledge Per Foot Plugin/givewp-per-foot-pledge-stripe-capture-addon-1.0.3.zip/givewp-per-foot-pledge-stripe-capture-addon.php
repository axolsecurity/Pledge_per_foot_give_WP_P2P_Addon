<?php
/**
 * Plugin Name: GiveWP Per-Foot Pledge — Stripe Capture Addon
 * Description: Adds Stripe card capture (SetupIntent) to the existing [gppf_pledge_form] and auto-fills the fundraiser name by reading it from the fundraiser page (GiveWP P2P) via localStorage handoff.
 * Version: 1.0.3
 * Author: Axolsoft LLC
 * License: GPLv2 or later
 * Text Domain: gppf-stripe-capture
 */

if ( ! defined('ABSPATH') ) { exit; }

define('GPPF_SC_VER', '1.0.3');
define('GPPF_SC_OPT', 'gppf_sc_options');

/**
 * Key detection: pull from this add-on's options, the base plugin (heuristics),
 * or GiveWP Stripe settings / constants.
 */
function gppf_sc_detect_keys() {
    $from = 'addon';
    $pk = '';
    $sk = '';

    // 1) Our own settings
    $o = get_option(GPPF_SC_OPT, []);
    if ( is_array($o) ) {
        $pk = isset($o['pk']) ? trim($o['pk']) : '';
        $sk = isset($o['sk']) ? trim($o['sk']) : '';
    }
    if ( $pk && $sk ) {
        return ['pk'=>$pk, 'sk'=>$sk, 'source'=>$from];
    }

    // 2) Try "base per-foot" plugin guesses.
    // Common option names and keys we might have used earlier.
    $base_option_candidates = [
        'gppf_options', 'gppf_settings', 'givewp_per_foot_pledge', 'gppf_stripe', 'givewp-per-foot-pledge-lite'
    ];
    $key_candidates_pk = ['pk','publishable_key','stripe_pk','stripe_publishable_key'];
    $key_candidates_sk = ['sk','secret_key','stripe_sk','stripe_secret_key'];

    foreach ($base_option_candidates as $opt) {
        $arr = get_option($opt);
        if ( is_array($arr) && !empty($arr) ) {
            $tmp_pk = ''; $tmp_sk = '';
            foreach ($key_candidates_pk as $k) { if (!empty($arr[$k])) { $tmp_pk = trim($arr[$k]); break; } }
            foreach ($key_candidates_sk as $k) { if (!empty($arr[$k])) { $tmp_sk = trim($arr[$k]); break; } }
            if ($tmp_pk && $tmp_sk) { return ['pk'=>$tmp_pk, 'sk'=>$tmp_sk, 'source'=>'base-plugin ('.$opt.')']; }
        }
    }

    // 3) GiveWP Stripe add-on settings (most likely stored as an array option).
    // Try option 'give_stripe_settings' first.
    $give_stripe = get_option('give_stripe_settings');
    if ( is_array($give_stripe) && !empty($give_stripe) ) {
        // Prefer live if present; otherwise test.
        $live_pk = isset($give_stripe['live_publishable_key']) ? trim($give_stripe['live_publishable_key']) : '';
        $live_sk = isset($give_stripe['live_secret_key']) ? trim($give_stripe['live_secret_key']) : '';
        $test_pk = isset($give_stripe['test_publishable_key']) ? trim($give_stripe['test_publishable_key']) : '';
        $test_sk = isset($give_stripe['test_secret_key']) ? trim($give_stripe['test_secret_key']) : '';

        // Some sites store env flag; we attempt to read typical flags.
        $env = 'live';
        if ( isset($give_stripe['environment']) ) {
            $env = strtolower(trim($give_stripe['environment'])) === 'test' ? 'test' : 'live';
        } elseif ( isset($give_stripe['test_mode']) ) {
            $env = ( $give_stripe['test_mode'] ) ? 'test' : 'live';
        }

        if ($env === 'live' && $live_pk && $live_sk) return ['pk'=>$live_pk, 'sk'=>$live_sk, 'source'=>'give_stripe_settings (live)'];
        if ($env === 'test' && $test_pk && $test_sk) return ['pk'=>$test_pk, 'sk'=>$test_sk, 'source'=>'give_stripe_settings (test)'];

        // Fallback: whichever pair exists.
        if ($live_pk && $live_sk) return ['pk'=>$live_pk, 'sk'=>$live_sk, 'source'=>'give_stripe_settings (live/fallback)'];
        if ($test_pk && $test_sk) return ['pk'=>$test_pk, 'sk'=>$test_sk, 'source'=>'give_stripe_settings (test/fallback)'];
    }

    // Also try a second common option name just in case.
    $give_stripe_2 = get_option('give_settings_stripe');
    if ( is_array($give_stripe_2) && !empty($give_stripe_2) ) {
        $live_pk = isset($give_stripe_2['live_publishable_key']) ? trim($give_stripe_2['live_publishable_key']) : '';
        $live_sk = isset($give_stripe_2['live_secret_key']) ? trim($give_stripe_2['live_secret_key']) : '';
        $test_pk = isset($give_stripe_2['test_publishable_key']) ? trim($give_stripe_2['test_publishable_key']) : '';
        $test_sk = isset($give_stripe_2['test_secret_key']) ? trim($give_stripe_2['test_secret_key']) : '';

        if ($live_pk && $live_sk) return ['pk'=>$live_pk, 'sk'=>$live_sk, 'source'=>'give_settings_stripe (live)'];
        if ($test_pk && $test_sk) return ['pk'=>$test_pk, 'sk'=>$test_sk, 'source'=>'give_settings_stripe (test)'];
    }

    // 4) Constants fallback
    if ( defined('GIVE_STRIPE_LIVE_PUBLISHABLE_KEY') && defined('GIVE_STRIPE_LIVE_SECRET_KEY') ) {
        $pk = constant('GIVE_STRIPE_LIVE_PUBLISHABLE_KEY');
        $sk = constant('GIVE_STRIPE_LIVE_SECRET_KEY');
        if ($pk && $sk) return ['pk'=>$pk, 'sk'=>$sk, 'source'=>'constants (live)'];
    }
    if ( defined('GIVE_STRIPE_TEST_PUBLISHABLE_KEY') && defined('GIVE_STRIPE_TEST_SECRET_KEY') ) {
        $pk = constant('GIVE_STRIPE_TEST_PUBLISHABLE_KEY');
        $sk = constant('GIVE_STRIPE_TEST_SECRET_KEY');
        if ($pk && $sk) return ['pk'=>$pk, 'sk'=>$sk, 'source'=>'constants (test)'];
    }

    // Nothing found.
    return ['pk'=>'', 'sk'=>'', 'source'=>'none'];
}

add_action('admin_menu', function () {
    add_options_page(
        __('Per-Foot Pledge — Stripe Capture','gppf-stripe-capture'),
        __('Per-Foot Pledge — Stripe Capture','gppf-stripe-capture'),
        'manage_options',
        'gppf-stripe-capture',
        function () {
            $det = gppf_sc_detect_keys();
            $verified = false;
            $acct = null;
            if ( !empty($det['sk']) ) {
                $resp = wp_remote_get('https://api.stripe.com/v1/accounts', [
                    'headers' => [ 'Authorization' => 'Basic ' . base64_encode($det['sk'] . ':' ) ],
                    'timeout' => 15,
                ]);
                if ( ! is_wp_error($resp) ) {
                    $code = wp_remote_retrieve_response_code($resp);
                    if ($code >= 200 && $code < 300) {
                        $verified = true;
                        $acct = json_decode(wp_remote_retrieve_body($resp), true);
                    }
                }
            }
            ?>
            <div class="wrap">
                <h1><?php esc_html_e('Per-Foot Pledge — Stripe Capture','gppf-stripe-capture'); ?></h1>

                <p><strong>Status:</strong>
                    <?php if ($verified): ?>
                        <span style="color:#0a7d0a;">&#x2714; Stripe keys verified</span>
                        <?php if (!empty($acct['id'])): ?>
                            <code>(<?php echo esc_html($acct['id']); ?>)</code>
                        <?php endif; ?>
                        <small>Source: <?php echo esc_html($det['source']); ?></small>
                    <?php else: ?>
                        <span style="color:#b40000;">&#x2716; Keys not verified</span>
                        <small>Source: <?php echo esc_html($det['source']); ?></small>
                    <?php endif; ?>
                </p>

                <form method="post" action="options.php">
                    <?php
                    settings_fields('gppf_sc_group');
                    do_settings_sections('gppf-sc');
                    submit_button();
                    ?>
                </form>

                <hr/>
                <p><strong>Auto name handoff:</strong> When a visitor clicks the “Pledge Per Foot” button on a GiveWP P2P fundraiser page, this add-on stores the fundraiser’s <em>name &amp; id</em> in the browser and the pledge page uses it automatically—no URL params required.</p>
                <p><em>Key lookup order:</em> Add-on settings → base per-foot plugin → GiveWP Stripe settings → constants.</p>
            </div>
            <?php
        }
    );
});

add_action('admin_init', function () {
    register_setting('gppf_sc_group', GPPF_SC_OPT, [
        'type' => 'array',
        'sanitize_callback' => function($in){
            $out = [];
            $out['pk'] = isset($in['pk']) ? sanitize_text_field($in['pk']) : '';
            $out['sk'] = isset($in['sk']) ? sanitize_text_field($in['sk']) : '';
            return $out;
        },
        'default' => []
    ]);

    add_settings_section('gppf_sc_keys', __('Stripe API Keys (override)','gppf-stripe-capture'), function(){
        echo '<p>'.esc_html__('Optional: enter keys here to override auto-detected ones. Use test keys on staging.', 'gppf-stripe-capture').'</p>';
    }, 'gppf-sc');

    add_settings_field('pk', __('Publishable Key','gppf-stripe-capture'), function(){
        $o = get_option(GPPF_SC_OPT, []);
        printf('<input type="text" name="%s[pk]" value="%s" class="regular-text" placeholder="pk_live_...">', esc_attr(GPPF_SC_OPT), esc_attr($o['pk'] ?? '') );
    }, 'gppf-sc', 'gppf_sc_keys');

    add_settings_field('sk', __('Secret Key','gppf-stripe-capture'), function(){
        $o = get_option(GPPF_SC_OPT, []);
        printf('<input type="password" name="%s[sk]" value="%s" class="regular-text" placeholder="sk_live_...">', esc_attr(GPPF_SC_OPT), esc_attr($o['sk'] ?? '') );
    }, 'gppf-sc', 'gppf_sc_keys');
});

function gppf_sc_is_fundraiser_page(){
    if ( is_admin() ) return false;
    $req_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    return (bool) preg_match('~/campaign/[^/]+/fundraiser/\\d+/?$~', $req_uri);
}
function gppf_sc_page_has_shortcode() {
    if ( is_admin() ) return false;
    global $post;
    if ( empty($post) || empty($post->post_content) ) {
        // Even if content missing, the add-on still tries DOM-scan on front-end.
        return true;
    }
    if ( has_shortcode( $post->post_content, 'gppf_pledge_form' ) ) return true;
    if ( has_shortcode( $post->post_content, 'per-foot-pledge' ) ) return true;
    return true;
}

add_action('wp_enqueue_scripts', function() {
    if ( gppf_sc_is_fundraiser_page() ) {
        wp_enqueue_script('gppf-sc-handoff', plugins_url('assets/js/handoff.js', __FILE__), [], GPPF_SC_VER, true);
    }
    if ( gppf_sc_page_has_shortcode() ) {
        $det = gppf_sc_detect_keys();
        $pk = $det['pk'];
        wp_enqueue_style('gppf-sc', plugins_url('assets/css/capture.css', __FILE__), [], GPPF_SC_VER);
        wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', [], null, true);
        wp_enqueue_script('gppf-sc', plugins_url('assets/js/capture.js', __FILE__), ['stripe-js'], GPPF_SC_VER, true);
        wp_localize_script('gppf-sc', 'GPPF_SC_VARS', [
            'ajax'  => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('gppf_sc_ajax'),
            'pk'    => $pk,
        ]);
    }
}, 20);

add_action('wp_ajax_gppf_sc_setup', 'gppf_sc_setup');
add_action('wp_ajax_nopriv_gppf_sc_setup', 'gppf_sc_setup');
function gppf_sc_setup(){
    check_ajax_referer('gppf_sc_ajax','nonce');
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $name  = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';

    $det = gppf_sc_detect_keys();
    $sk = $det['sk'];
    if ( empty($sk) ) wp_send_json_error(['message' => 'Stripe secret key not configured'], 400);

    $resp_c = wp_remote_post('https://api.stripe.com/v1/customers', [
        'headers' => [ 'Authorization' => 'Basic ' . base64_encode($sk . ':' ) ],
        'timeout' => 20,
        'body'    => [ 'email' => $email, 'name' => $name ]
    ]);
    if ( is_wp_error($resp_c) ) wp_send_json_error(['message' => $resp_c->get_error_message()], 500);
    $code_c = wp_remote_retrieve_response_code($resp_c);
    $body_c = json_decode(wp_remote_retrieve_body($resp_c), true);
    if ( $code_c < 200 || $code_c >= 300 || empty($body_c['id']) ) {
        wp_send_json_error(['message' => 'Stripe customer creation failed', 'raw' => $body_c], 500);
    }
    $customer_id = $body_c['id'];

    $resp_s = wp_remote_post('https://api.stripe.com/v1/setup_intents', [
        'headers' => [ 'Authorization' => 'Basic ' . base64_encode($sk . ':' ) ],
        'timeout' => 20,
        'body'    => [ 'customer' => $customer_id, 'usage' => 'off_session' ]
    ]);
    if ( is_wp_error($resp_s) ) wp_send_json_error(['message' => $resp_s->get_error_message()], 500);
    $code_s = wp_remote_retrieve_response_code($resp_s);
    $body_s = json_decode(wp_remote_retrieve_body($resp_s), true);
    if ( $code_s < 200 || $code_s >= 300 || empty($body_s['client_secret']) ) {
        wp_send_json_error(['message' => 'Stripe SetupIntent creation failed', 'raw' => $body_s], 500);
    }

    wp_send_json_success([
        'client_secret'  => $body_s['client_secret'],
        'customer'       => $customer_id
    ]);
}

add_filter('the_content', function($content){
    if ( ! gppf_sc_page_has_shortcode() ) return $content;
    $hook = '<div id="gppf-sc-mount" style="display:none"></div>';
    return $content . "\n" . $hook;
}, 20);
