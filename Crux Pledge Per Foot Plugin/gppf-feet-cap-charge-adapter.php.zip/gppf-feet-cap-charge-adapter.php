<?php
/**
 * Plugin Name: GPPF Feet-Cap Charge Adapter
 * Description: Converts FEET CAP → Dollar Cap before charging, shows inline charge previews, performs real Stripe charges (optional), and adds a Status column (edited via form submit). No JS/AJAX.
 * Version: 0.4.3
 * Author: Axolsoft, LLC
 * License: GPL-2.0-or-later
 */

if ( ! defined('ABSPATH') ) { exit; }

define('GPPF_FCAA_OPT', 'gppf_feet_cap_charge_adapter');
define('GPPF_FCAA_NONCE', 'gppf_fcaa_nonce_v042');

/* =========================
 * SETTINGS PAGE (Stripe SK, currency)
 * ========================= */
add_action('admin_menu', function(){
    add_options_page('Feet-Cap Charge Adapter','Feet-Cap Charge Adapter','manage_options','gppf-feet-cap-adapter','gppf_fcaa_settings_page');
});
add_action('admin_init', function(){
    register_setting('gppf_fcaa', GPPF_FCAA_OPT);
    add_settings_section('gppf_fcaa_main','Stripe Settings','__return_null','gppf-feet-cap-adapter');
    add_settings_field('gppf_fcaa_sk','Stripe Secret Key','gppf_fcaa_field_sk','gppf-feet-cap-adapter','gppf_fcaa_main');
    add_settings_field('gppf_fcaa_currency','Currency (ISO)','gppf_fcaa_field_currency','gppf-feet-cap-adapter','gppf_fcaa_main');
});
function gppf_fcaa_field_sk(){
    $opt = get_option(GPPF_FCAA_OPT, array());
    $sk  = isset($opt['sk']) ? $opt['sk'] : '';
    echo '<input type="password" name="'.esc_attr(GPPF_FCAA_OPT).'[sk]" value="'.esc_attr($sk).'" style="width: 400px;" placeholder="sk_live_... or sk_test_...">';
}
function gppf_fcaa_field_currency(){
    $opt = get_option(GPPF_FCAA_OPT, array());
    $cur = isset($opt['currency']) ? $opt['currency'] : 'usd';
    echo '<input type="text" name="'.esc_attr(GPPF_FCAA_OPT).'[currency]" value="'.esc_attr($cur).'" style="width: 120px;" placeholder="usd">';
}
function gppf_fcaa_settings_page(){
    ?>
    <div class="wrap">
      <h1>Feet-Cap Charge Adapter</h1>
      <form method="post" action="options.php">
        <?php
          settings_fields('gppf_fcaa');
          do_settings_sections('gppf-feet-cap-adapter');
          submit_button('Save Settings');
        ?>
      </form>
      <p class="description">Provide your <strong>Stripe Secret Key</strong> and currency to let this adapter perform real charges. If not provided, the adapter will only show previews and set dollar caps for the Lite plugin.</p>
    </div>
    <?php
}

/* =========================
 * Utilities
 * ========================= */
function gppf_fcaa_get_status($pledge_id){
    $st = get_post_meta($pledge_id, '_gppf_status', true);
    if (!$st) { $st = 'waiting'; update_post_meta($pledge_id, '_gppf_status', $st); }
    return $st;
}
function gppf_fcaa_set_status($pledge_id, $status){
    $allowed = array('waiting','charged','failed');
    if (!in_array($status, $allowed, true)) return false;
    update_post_meta($pledge_id, '_gppf_status', $status);
    return true;
}

/* =========================
 * PART 1 — FEET→DOLLAR CAP before Lite math (on charge submit)
 * ========================= */
add_action('admin_init', function(){
    if ( empty($_POST['gppf_charge_fid']) ) return;
    $fid = sanitize_text_field($_POST['gppf_charge_fid']);
    $nonce_ok = isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'gppf_charge_' . $fid);
    if ( ! $nonce_ok ) return;

    $final_feet = intval( get_option('gppf_final_feet_' . $fid, 0) );
    $pledges = get_posts(array(
        'post_type'   => 'ppf_pledge','post_status' => 'publish','numberposts' => -1,
        'meta_key'    => '_gppf_fundraiser_id','meta_value'  => $fid,
        'no_found_rows'=>true,'update_post_meta_cache'=>false,'update_post_term_cache'=>false,
    ));

    foreach ($pledges as $p) {
        gppf_fcaa_get_status($p->ID);

        $rate     = floatval( get_post_meta($p->ID, '_gppf_rate', true) );
        $feet_cap = get_post_meta($p->ID, '_gppf_feet_cap', true);
        $feet_cap = ($feet_cap !== '') ? floatval($feet_cap) : 0;

        if ($feet_cap > 0) {
            $dollar_cap = $rate * $feet_cap;
            if ($final_feet >= $feet_cap) {
                update_post_meta($p->ID, '_gppf_cap', $dollar_cap);
            } else {
                delete_post_meta($p->ID, '_gppf_cap');
            }
        } else {
            delete_post_meta($p->ID, '_gppf_cap');
        }
    }

    add_action('admin_notices', function() use ($fid, $final_feet){
        echo '<div class="notice notice-success"><p>Feet-Cap Adapter applied for fundraiser #'.esc_html($fid).'. Final feet: '.intval($final_feet).'.</p></div>';
    });
}, 1);

/* =========================
 * PART 2 — Status form handler (no JS)
 * ========================= */
add_action('admin_init', function(){
    if ( empty($_POST['gppf_update_status_fid']) ) return;
    if ( ! current_user_can('manage_options') ) return;
    $fid = sanitize_text_field($_POST['gppf_update_status_fid']);
    check_admin_referer(GPPF_FCAA_NONCE . '_' . $fid);
    if ( ! empty($_POST['gppf_status']) && is_array($_POST['gppf_status']) ){
        foreach ($_POST['gppf_status'] as $pid => $st){
            $pid = intval($pid);
            $st = sanitize_text_field($st);
            gppf_fcaa_set_status($pid, $st);
        }
    }
    add_action('admin_notices', function(){
        echo '<div class="notice notice-success"><p>Status updated.</p></div>';
    });
});

/* =========================
 * PART 3 — Inline Preview + Status column (with submit button)
 * ========================= */
add_action('admin_notices', function(){
    if ( ! current_user_can('manage_options') ) return;
    if ( ! isset($_GET['page']) || $_GET['page'] !== 'gppf-charges' ) return;

    // Inline CSS (color-coded, bold status text)
    echo '<style>
    .gppf-status-select { font-weight:700; }
    .gppf-status-waiting { color:#6c757d; font-weight:700; }
    .gppf-status-charged { color:#28a745; font-weight:700; }
    .gppf-status-failed  { color:#dc3545; font-weight:700; }
    </style>';

    $pledges = get_posts(array(
        'post_type'   => 'ppf_pledge','post_status' => 'publish','numberposts' => -1,
        'no_found_rows'=>true,'update_post_meta_cache'=>false,'update_post_term_cache'=>false,
    ));
    if (empty($pledges)) {
        echo '<div class="notice notice-info"><p>No pledges found for preview.</p></div>';
        return;
    }

    $by = array();
    foreach ($pledges as $p) {
        $fid = get_post_meta($p->ID, '_gppf_fundraiser_id', true);
        if ( ! $fid ) $fid = 'unknown';
        $by[$fid][] = $p->ID;
    }

    foreach ($by as $fid => $ids) {
        $first_id = reset($ids);
        $fundraiser_name = $first_id ? get_post_meta($first_id, '_gppf_fundraiser_name', true) : '';
        $final_feet = intval( get_option('gppf_final_feet_' . $fid, 0) );

        echo '<div class="postbox" style="padding: 10px; margin-top: 12px;">';
        echo '<h2 style="margin:0 0 10px 0;">Charge Preview — ' . esc_html( $fundraiser_name ? $fundraiser_name : 'Unknown' ) . ' (#' . esc_html($fid) . ')</h2>';

        // Begin form for statuses
        echo '<form method="post">';
        wp_nonce_field(GPPF_FCAA_NONCE . '_' . $fid);
        echo '<input type="hidden" name="gppf_update_status_fid" value="'.esc_attr($fid).'">';

        echo '<table class="widefat striped"><thead><tr>';
        echo '<th style="width:100px;">Pledge&nbsp;ID</th><th>Donor</th><th style="width:90px;">$/ft</th><th style="width:110px;">Feet&nbsp;Cap</th><th style="width:110px;">Final&nbsp;Feet</th><th style="width:140px;">Effective&nbsp;Feet</th><th style="width:160px;">Expected&nbsp;Charge</th><th style="width:160px;">Status</th>';
        echo '</tr></thead><tbody>';

        $grand_total = 0.0;
        foreach ($ids as $pid) {
            $status = gppf_fcaa_get_status($pid);

            $rate       = floatval( get_post_meta($pid, '_gppf_rate', true) );
            $feet_cap_m = get_post_meta($pid, '_gppf_feet_cap', true);
            $feet_cap   = ($feet_cap_m !== '') ? floatval($feet_cap_m) : 0;
            $donor      = get_post_meta($pid, '_gppf_donor_name', true);
            if (!$donor) $donor = 'Anonymous';

            $effective_feet = $final_feet;
            if ($feet_cap > 0 && $feet_cap < $effective_feet) $effective_feet = $feet_cap;

            $amount = $rate * $effective_feet; $grand_total += $amount;

            $cls = ($status==='charged' ? 'gppf-status-charged' : ($status==='failed' ? 'gppf-status-failed' : 'gppf-status-waiting'));

            echo '<tr>';
            echo '<td>' . intval($pid) . '</td>';
            echo '<td>' . esc_html($donor) . '</td>';
            echo '<td>$' . esc_html( number_format_i18n( $rate, 2 ) ) . '</td>';
            echo '<td>' . ( $feet_cap > 0 ? esc_html( number_format_i18n( $feet_cap, 0 ) ) : '&mdash;' ) . '</td>';
            echo '<td>' . esc_html( number_format_i18n( $final_feet, 0 ) ) . '</td>';
            echo '<td>' . esc_html( number_format_i18n( $effective_feet, 0 ) ) . '</td>';
            echo '<td><strong>$' . esc_html( number_format_i18n( $amount, 2 ) ) . '</strong></td>';
            echo '<td>';
            echo '<select name="gppf_status['.intval($pid).']" class="gppf-status-select '.$cls.'">';
            echo '<option value="waiting" '.selected($status,'waiting',false).'>WAITING</option>';
            echo '<option value="charged" '.selected($status,'charged',false).'>CHARGED</option>';
            echo '<option value="failed"  '.selected($status,'failed',false).'>FAILED</option>';
            echo '</select>';
            echo '</td>';
            echo '</tr>';
        }
        echo '<tr><td colspan="6" style="text-align:right;"><strong>Total Expected Charges:</strong></td><td><strong>$' . esc_html( number_format_i18n( $grand_total, 2 ) ) . '</strong></td><td></td></tr>';
        echo '</tbody></table>';
        submit_button('Save Statuses', 'secondary', 'gppf_save_statuses', false);
        echo '</form>';

        echo '<p class="description" style="margin-top:8px;">Preview uses: amount = rate × min(final feet, feet cap). Status changes are saved by the button above (no JavaScript).</p>';
        echo '</div>';
    }
});

/* =========================
 * PART 4 — Real Stripe Charge (optional, only if SK is set) with status updates; skips CHARGED
 * ========================= */
add_action('admin_init', function(){
    if ( empty($_POST['gppf_charge_fid']) ) return;
    $fid = sanitize_text_field($_POST['gppf_charge_fid']);
    $nonce_ok = isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'], 'gppf_charge_' . $fid);
    if ( ! $nonce_ok ) return;

    $opt = get_option(GPPF_FCAA_OPT, array());
    $sk  = isset($opt['sk']) ? trim($opt['sk']) : '';
    $currency = isset($opt['currency']) ? strtolower(trim($opt['currency'])) : 'usd';

    if ( ! $sk ) {
        add_action('admin_notices', function(){
            echo '<div class="notice notice-warning"><p>Feet-Cap Adapter: No Stripe Secret Key set. Charges will NOT be sent to Stripe; only the Lite plugin emails will run.</p></div>';
        });
        return;
    }

    if ( get_transient('gppf_fcaa_charging_'.$fid) ) return;
    set_transient('gppf_fcaa_charging_'.$fid, 1, 60);

    $final_feet = intval( get_option('gppf_final_feet_' . $fid, 0) );
    $pledges = get_posts(array(
        'post_type'=>'ppf_pledge','post_status'=>'publish','numberposts'=>-1,
        'meta_key'=>'_gppf_fundraiser_id','meta_value'=>$fid,
        'no_found_rows'=>true,'update_post_meta_cache'=>false,'update_post_term_cache'=>false,
    ));

    $success = 0; $fail = 0; $skipped = 0;
    foreach($pledges as $p){
        $status = gppf_fcaa_get_status($p->ID);
        if ($status === 'charged') { $skipped++; continue; }

        $rate     = floatval(get_post_meta($p->ID,'_gppf_rate',true));
        $feet_cap = get_post_meta($p->ID,'_gppf_feet_cap',true);
        $feet_cap = ($feet_cap !== '') ? floatval($feet_cap) : 0;
        $effective_feet = $final_feet;
        if ($feet_cap > 0 && $feet_cap < $effective_feet) $effective_feet = $feet_cap;
        $amount = $rate * $effective_feet;
        if ($amount < 0.5){ gppf_fcaa_set_status($p->ID,'failed'); $fail++; continue; }

        $customer = get_post_meta($p->ID,'_gppf_stripe_customer',true);
        $pm       = get_post_meta($p->ID,'_gppf_payment_method',true);
        if ( ! $customer || ! $pm ) { gppf_fcaa_set_status($p->ID,'failed'); $fail++; continue; }

        $cents = intval(round($amount * 100));
        $body = array(
            'amount' => $cents,
            'currency' => $currency,
            'customer' => $customer,
            'payment_method' => $pm,
            'confirm' => 'true',
            'off_session' => 'true',
            'description' => sprintf('Per-Foot Pledge #%d: %s ft × $%0.2f/ft', $p->ID, $effective_feet, $rate),
            'metadata' => array('pledge_id'=>(string)$p->ID, 'fundraiser_id'=>(string)$fid),
        );

        $resp = wp_remote_post('https://api.stripe.com/v1/payment_intents', array(
            'headers' => array('Authorization' => 'Basic ' . base64_encode($sk . ':'),),
            'body' => $body,
            'timeout' => 30,
        ));

        if ( is_wp_error($resp) ) {
            gppf_fcaa_set_status($p->ID,'failed'); $fail++; continue;
        }
        $code = wp_remote_retrieve_response_code($resp);
        $json = json_decode(wp_remote_retrieve_body($resp), true);

        if ( $code >= 200 && $code < 300 && !empty($json['id']) ) {
            $success++;
            gppf_fcaa_set_status($p->ID,'charged');
            update_post_meta($p->ID,'_gppf_last_charged', current_time('mysql'));
            update_post_meta($p->ID,'_gppf_last_amount', $amount);
            update_post_meta($p->ID,'_gppf_last_intent', sanitize_text_field($json['id']));
        } else {
            gppf_fcaa_set_status($p->ID,'failed'); $fail++;
        }
    }

    
    // IMPORTANT: Prevent the Lite plugin from running its own charge/email loop in this request,
    // which would otherwise send duplicate emails for already-charged pledges.
    if (isset($_POST['gppf_charge_fid'])) { unset($_POST['gppf_charge_fid']); }
add_action('admin_notices', function() use ($success,$fail,$skipped){
        echo '<div class="notice notice-info"><p>Feet-Cap Adapter (Stripe): Success: '.intval($success).', Failed: '.intval($fail).', Skipped (already Charged): '.intval($skipped).'.</p></div>';
    });
}, 5);
